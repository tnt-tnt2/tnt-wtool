"""TNT Write Tool V5 - PC app. Write on the PC screen from a tablet (S Pen), control the PC remotely."""
import asyncio, hmac, io, json, os, secrets, shutil, socket, subprocess, sys, threading, time
from urllib.parse import quote
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import mss, pyautogui, qrcode
from aiohttp import web, WSMsgType
from PIL import Image
from PyQt6 import QtCore, QtGui, QtWidgets as QW

APP, VERSION, PORT = "TNT Write Tool", "V5", 8765
CFG_DIR = Path.home() / ".tnt_write_tool"
CFG_FILE = CFG_DIR / "config.json"
pyautogui.PAUSE = 0
pyautogui.FAILSAFE = False
Qt = QtCore.Qt


def resource(name):
    return Path(getattr(sys, "_MEIPASS", Path(__file__).parent)) / name


class Config:
    def __init__(self):
        self.d = {"name": socket.gethostname(), "tokens": {}}
        try:
            self.d.update(json.loads(CFG_FILE.read_text()))
        except Exception:
            pass
        self.d.setdefault("id", secrets.token_hex(4))
        self.new_code()

    def new_code(self):
        self.code = f"{secrets.randbelow(10**6):06d}"

    def save(self):
        try:
            CFG_DIR.mkdir(exist_ok=True)
            CFG_FILE.write_text(json.dumps(self.d))
        except Exception:
            pass


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # no packet is sent
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


class Bridge(QtCore.QObject):
    cmd = QtCore.pyqtSignal(dict)      # drawing commands -> overlay
    status = QtCore.pyqtSignal(str)    # connected device name ("" = none)


# ----------------------------------------------------------------- overlay
class Overlay(QW.QWidget):
    def __init__(self):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
                         | Qt.WindowType.Tool | Qt.WindowType.WindowTransparentForInput
                         | Qt.WindowType.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        scr = QW.QApplication.primaryScreen()
        self.setGeometry(scr.geometry())
        dpr = scr.devicePixelRatio()
        self.base = QtGui.QPixmap(int(self.width() * dpr), int(self.height() * dpr))
        self.base.setDevicePixelRatio(dpr)
        self.base.fill(Qt.GlobalColor.transparent)
        self.strokes, self.cur, self.scale, self.msg = [], None, self.width() / 1920, ""

    # drawing helpers
    def _painter(self, dev):
        p = QtGui.QPainter(dev)
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        return p

    @staticmethod
    def _pen(color, w):
        return QtGui.QPen(color, max(1.0, w), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)

    def _render(self, p, s):
        pts = s["pts"]
        if s["hi"]:
            c = QtGui.QColor(s["color"]); c.setAlpha(110)
            path = QtGui.QPainterPath(QtCore.QPointF(pts[0][0], pts[0][1]))
            for x, y, _ in pts[1:] or [pts[0]]:
                path.lineTo(x, y)
            p.setPen(self._pen(c, pts[0][2]))
            p.drawPath(path)
        else:
            c = QtGui.QColor(s["color"])
            if len(pts) == 1:
                p.setPen(self._pen(c, pts[0][2])); p.drawPoint(QtCore.QPointF(pts[0][0], pts[0][1]))
            for a, b in zip(pts, pts[1:]):
                p.setPen(self._pen(c, b[2])); p.drawLine(QtCore.QPointF(a[0], a[1]), QtCore.QPointF(b[0], b[1]))

    def _rebuild(self):
        self.base.fill(Qt.GlobalColor.transparent)
        p = self._painter(self.base)
        for s in self.strokes:
            self._render(p, s)
        p.end(); self.update()

    def paintEvent(self, _):
        p = QtGui.QPainter(self)
        p.drawPixmap(0, 0, self.base)
        if self.cur and self.cur["hi"]:
            p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing); self._render(p, self.cur)
        if self.msg:  # small on-screen notice, e.g. "Tablet connected"
            p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
            f = p.font(); f.setPixelSize(17); f.setBold(True); p.setFont(f)
            w = QtGui.QFontMetrics(f).horizontalAdvance(self.msg) + 56
            r = QtCore.QRectF((self.width() - w) / 2, 22, w, 46)
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(QtGui.QColor(16, 20, 26, 225)); p.drawRoundedRect(r, 23, 23)
            p.setPen(QtGui.QColor("#e6edf3")); p.drawText(r, Qt.AlignmentFlag.AlignCenter, self.msg)

    def toast(self, text):
        self.msg = text; self.update()
        QtCore.QTimer.singleShot(2800, lambda: (setattr(self, "msg", ""), self.update()))

    # commands
    def handle(self, d):
        try:
            t = d.get("t")
            if t == "draw":
                self._draw(d)
            elif t == "erase":
                self._erase(d)
            elif t == "undo" and self.strokes:
                self.strokes.pop(); self._rebuild()
            elif t == "clear":
                self.strokes.clear(); self.cur = None; self._rebuild()
            elif t == "overlay":
                self.setVisible(bool(d.get("show")))
        except Exception as e:  # never let a bad packet kill the overlay
            print("overlay error:", e)

    def _conv(self, pts, hi):
        k = self.scale
        return [(x * self.width(), y * self.height(), w * k * (1 if hi else 1)) for x, y, w in pts]

    def _draw(self, d):
        ph, hi = d["p"], bool(d.get("hi"))
        if ph == "start":
            self.cur = {"id": d["id"], "color": d.get("color", "#ff3b30"), "hi": hi, "pts": self._conv(d["pts"][:1], hi)}
            self.strokes.append(self.cur)
            if not hi:
                p = self._painter(self.base); self._render(p, self.cur); p.end()
            self.update(); return
        s = self.cur
        if not s or s["id"] != d["id"]:
            return
        if ph == "move":
            new = self._conv(d["pts"], s["hi"])
            old_last = s["pts"][-1]
            s["pts"] += new
            if s["hi"]:
                s["pts"][:] = [(x, y, s["pts"][0][2]) for x, y, _ in s["pts"]]
            else:
                p = self._painter(self.base)
                prev = old_last
                for q in new:
                    p.setPen(self._pen(QtGui.QColor(s["color"]), q[2]))
                    p.drawLine(QtCore.QPointF(prev[0], prev[1]), QtCore.QPointF(q[0], q[1])); prev = q
                p.end()
            xs = [q[0] for q in new] + [old_last[0]]; ys = [q[1] for q in new] + [old_last[1]]
            m = int(s["pts"][0][2] + 4)
            if s["hi"]:
                self.update()
            else:
                self.update(QtCore.QRect(int(min(xs)) - m, int(min(ys)) - m, int(max(xs) - min(xs)) + 2 * m, int(max(ys) - min(ys)) + 2 * m))
        elif ph == "end":
            if s["hi"]:
                p = self._painter(self.base); self._render(p, s); p.end()
            self.cur = None; self.update()

    @staticmethod
    def _dist(px, py, a, b):
        ax, ay, bx, by = a[0], a[1], b[0], b[1]
        dx, dy = bx - ax, by - ay
        t = 0 if dx == dy == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
        return ((px - ax - t * dx) ** 2 + (py - ay - t * dy) ** 2) ** 0.5

    def _erase(self, d):
        x, y, r = d["x"] * self.width(), d["y"] * self.height(), d.get("r", 0.012) * self.width()
        keep = [s for s in self.strokes if not any(self._dist(x, y, a, b) < r + b[2] / 2 for a, b in zip(s["pts"], s["pts"][1:] or [s["pts"][0]]))
                or s is self.cur]
        if len(keep) != len(self.strokes):
            self.strokes[:] = keep; self._rebuild()


# ------------------------------------------------------------------ server
class Server:
    def __init__(self, cfg, bridge):
        self.cfg, self.bridge, self.port = cfg, bridge, PORT
        self.active, self.fails = None, {}
        self.input_pool = ThreadPoolExecutor(1)
        self.ready = threading.Event()
        self.W, self.H = self._screen_size()
        self.tl = threading.local()
        self.html = resource("tablet.html").read_text(encoding="utf-8").replace("{{VERSION}}", VERSION).replace("{{PCID}}", cfg.d["id"])
        self.app_html = resource("app.html").read_text(encoding="utf-8").replace("{{VERSION}}", VERSION)

    @staticmethod
    def _screen_size():
        with mss.mss() as s:
            m = s.monitors[1]; return m["width"], m["height"]

    def grab(self, width):
        if not hasattr(self.tl, "sct"):
            self.tl.sct = mss.mss()
        s = self.tl.sct.grab(self.tl.sct.monitors[1])
        img = Image.frombytes("RGB", s.size, s.bgra, "raw", "BGRX")
        if img.width > width:
            img = img.resize((width, int(img.height * width / img.width)), Image.BILINEAR)
        b = io.BytesIO(); img.save(b, "JPEG", quality=60)
        return b.getvalue()

    async def stream(self, ws):
        loop, width = asyncio.get_running_loop(), 1280
        while not ws.closed:
            t0 = time.time()
            data = await loop.run_in_executor(None, self.grab, width)
            await ws.send_bytes(data)
            dt = time.time() - t0
            width = max(800, width - 160) if dt > 0.15 else min(1600, width + 80) if dt < 0.05 else width  # adapt to Wi-Fi
            await asyncio.sleep(max(0, 1 / 15 - dt))

    def auth(self, d, ip):
        f = self.fails.get(ip, (0, 0))
        if f[1] > time.time():
            return None, "locked"
        tok, code = d.get("token"), str(d.get("code") or "")
        if not tok and not code:
            return None, "need"
        if tok and tok in self.cfg.d["tokens"]:
            return tok, ""
        if code and hmac.compare_digest(code, self.cfg.code):
            tok = secrets.token_urlsafe(24)
            self.cfg.d["tokens"][tok] = str(d.get("device", "Tablet"))[:40]; self.cfg.save()
            return tok, ""
        n = f[0] + 1
        self.fails[ip] = (0, time.time() + 60) if n >= 5 else (n, 0)
        return None, "bad"

    def _mouse(self, d):
        try:
            if "x" in d:
                pyautogui.moveTo(int(d["x"] * (self.W - 1)), int(d["y"] * (self.H - 1)), _pause=False)
            a = d["a"]
            if a == "down": pyautogui.mouseDown()
            elif a == "up": pyautogui.mouseUp()
            elif a == "rclick": pyautogui.click(button="right")
            elif a == "scroll": pyautogui.scroll(int(d.get("dy", 0)) * 100)
        except Exception as e:
            print("mouse error:", e)

    def _keys(self, d):
        try:
            if d["t"] == "hotkey": pyautogui.hotkey(*d["keys"])
            elif d["t"] == "press": pyautogui.press(d["key"])
            elif d["t"] == "text": pyautogui.write(d["text"], interval=0)
        except Exception as e:
            print("key error:", e)

    def beacon(self):
        """Tell tablets on the Wi-Fi that this PC is here (UDP broadcast every 2 s)."""
        while True:
            try:
                ip = lan_ip()
                msg = f"TNT1|{self.cfg.d['name'].replace('|', '/')}|{self.port}|{self.cfg.d['id']}".encode()
                sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sk.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                try: sk.bind((ip, 0))
                except OSError: pass
                for dst in {"255.255.255.255", ip.rsplit(".", 1)[0] + ".255"}:
                    try: sk.sendto(msg, (dst, 48765))
                    except OSError: pass
                sk.close()
            except Exception:
                pass
            time.sleep(2)

    def find_apk(self):
        here = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).parent
        for d in (here, resource(""), CFG_DIR):
            try:
                for f in sorted(Path(d).glob("*.apk")):
                    return f
            except Exception:
                pass
        return None

    async def apk(self, req):
        f = self.find_apk()
        if not f:
            return web.Response(status=404, text="APK not found")
        return web.FileResponse(f, headers={"Content-Type": "application/vnd.android.package-archive",
                                            "Content-Disposition": 'attachment; filename="TNT-Write-Tool-' + VERSION + '.apk"'})

    async def ws_handler(self, req):
        ws = web.WebSocketResponse(heartbeat=8, max_msg_size=1 << 20)
        await ws.prepare(req)
        try:
            tok, err = self.auth(await asyncio.wait_for(ws.receive_json(), 10), req.remote)
        except Exception:
            await ws.close(); return ws
        if not tok:
            await ws.send_json({"t": "auth", "ok": False, "err": err}); await ws.close(); return ws
        if self.active is not None and not self.active.closed:
            await self.active.close()  # newest tablet wins
        self.active = ws
        self.bridge.status.emit(self.cfg.d["tokens"].get(tok, "Tablet"))
        await ws.send_json({"t": "auth", "ok": True, "token": tok, "name": self.cfg.d["name"], "w": self.W, "h": self.H})
        task = None
        try:
            async for msg in ws:
                if msg.type != WSMsgType.TEXT:
                    continue
                try:
                    d = json.loads(msg.data); t = d.get("t")
                    if t == "view":
                        if task: task.cancel()
                        task = asyncio.create_task(self.stream(ws)) if d.get("on") else None
                    elif t == "mouse": self.input_pool.submit(self._mouse, d)
                    elif t in ("hotkey", "press", "text"): self.input_pool.submit(self._keys, d)
                    elif t == "ping": await ws.send_json({"t": "pong"})
                    else: self.bridge.cmd.emit(d)
                except Exception as e:
                    print("bad message:", e)
        finally:
            if task: task.cancel()
            if self.active is ws:
                self.active = None; self.bridge.status.emit("")
        return ws

    def run(self):
        loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop)
        app = web.Application()
        app.add_routes([web.get("/", lambda r: web.Response(text=self.html, content_type="text/html")),
                        web.get("/ws", self.ws_handler),
                        web.get("/app", lambda r: web.Response(text=self.app_html, content_type="text/html")),
                        web.get("/tnt.apk", self.apk),
                        web.get("/icon.png", lambda r: web.FileResponse(resource("icon.png")))])
        runner = web.AppRunner(app); loop.run_until_complete(runner.setup())
        for p in range(PORT, PORT + 10):
            try:
                loop.run_until_complete(web.TCPSite(runner, "0.0.0.0", p).start()); self.port = p; break
            except OSError:
                continue
        threading.Thread(target=self.beacon, daemon=True).start()
        self.ready.set(); loop.run_forever()


# ---------------------------------------------------------------------- UI
STYLE = """
QWidget{background:#0d1117;color:#e6edf3;font-family:'Segoe UI',sans-serif;font-size:14px}
QFrame#card{background:#161b22;border:1px solid #262c36;border-radius:16px}
QLabel{background:transparent}
QLabel#h{font-size:26px;font-weight:700} QLabel#ver{background:#1f6feb;border-radius:9px;padding:2px 10px;font-weight:700;font-size:13px}
QLabel#cap{color:#8b949e;font-size:12px;font-weight:600}
QLabel#code{font-size:50px;font-weight:800;letter-spacing:10px;color:#58a6ff}
QLabel#pill{border-radius:14px;padding:8px 16px;background:#21262d;font-weight:600}
QPushButton{background:#21262d;border:1px solid #30363d;border-radius:10px;padding:11px 14px;font-weight:600}
QPushButton:hover{background:#2d333b;border-color:#58a6ff} QPushButton#primary{background:#1f6feb;border-color:#388bfd}
QLineEdit{background:#0d1117;border:1px solid #30363d;border-radius:10px;padding:9px;font-size:15px}
QLineEdit:focus{border-color:#58a6ff}
QCheckBox::indicator{width:18px;height:18px;border:1px solid #30363d;border-radius:5px;background:#0d1117}
QCheckBox::indicator:checked{background:#1f6feb;border-color:#58a6ff} QCheckBox{spacing:8px;background:transparent;min-height:26px}
"""
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"


def autostart_get():
    if sys.platform != "win32":
        return False
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
            winreg.QueryValueEx(k, APP); return True
    except OSError:
        return False


def autostart_set(on):
    if sys.platform != "win32":
        return
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
        if on:
            winreg.SetValueEx(k, APP, 0, winreg.REG_SZ, f'"{sys.executable}" --minimized')
        else:
            try: winreg.DeleteValue(k, APP)
            except OSError: pass


def app_icon():
    p = resource("icon.png")
    if p.exists():
        return QtGui.QIcon(str(p))
    pm = QtGui.QPixmap(64, 64); pm.fill(Qt.GlobalColor.transparent)
    q = QtGui.QPainter(pm); q.setBrush(QtGui.QColor("#1f6feb")); q.setPen(Qt.PenStyle.NoPen); q.drawRoundedRect(2, 2, 60, 60, 14, 14); q.end()
    return QtGui.QIcon(pm)


def card():
    f = QW.QFrame(); f.setObjectName("card"); return f


class Main(QW.QWidget):
    def __init__(self, cfg, server, bridge, overlay):
        super().__init__()
        self.cfg, self.srv, self.overlay, self.url = cfg, server, overlay, ""
        self.setWindowTitle(f"{APP} {VERSION}"); self.setWindowIcon(app_icon()); self.setStyleSheet(STYLE)
        self.setFixedSize(800, 540)

        # left card: QR
        qc = card(); ql = QW.QVBoxLayout(qc); ql.setContentsMargins(20, 20, 20, 20)
        self.qr = QW.QLabel(); self.qr.setFixedSize(250, 250); self.qr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cap = QW.QLabel("NEW TABLET? SCAN TO GET THE APP"); cap.setObjectName("cap"); cap.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.addr = QW.QLabel(); self.addr.setAlignment(Qt.AlignmentFlag.AlignCenter); self.addr.setStyleSheet("color:#8b949e")
        self.addr.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.apkl = QW.QLabel(); self.apkl.setAlignment(Qt.AlignmentFlag.AlignCenter); self.apkl.setWordWrap(True)
        ql.addWidget(self.qr); ql.addWidget(cap); ql.addWidget(self.addr); ql.addWidget(self.apkl); ql.addStretch()

        # header
        logo = QW.QLabel(); logo.setPixmap(app_icon().pixmap(56, 56))
        title = QW.QLabel(APP); title.setObjectName("h")
        ver = QW.QLabel(VERSION); ver.setObjectName("ver"); ver.setFixedHeight(24); ver.setAlignment(Qt.AlignmentFlag.AlignCenter)
        head = QW.QHBoxLayout(); head.setSpacing(12)
        for w in (logo, title, ver): head.addWidget(w)
        head.addStretch()

        # right card: pairing + controls
        self.code = QW.QLabel(); self.code.setObjectName("code")
        self.name = QW.QLineEdit(cfg.d["name"]); self.name.editingFinished.connect(self.rename)
        self.pill = QW.QLabel(); self.pill.setObjectName("pill"); self.set_status("")
        c1 = QW.QLabel("PAIRING CODE"); c1.setObjectName("cap")
        c2 = QW.QLabel("PC NAME (SHOWN ON THE TABLET)"); c2.setObjectName("cap")
        grid = QW.QGridLayout(); grid.setSpacing(8)
        for i, (text, fn, prim) in enumerate([("Hide / show board", self.toggle, True), ("Clear board", lambda: overlay.handle({"t": "clear"}), False),
                                              ("New code", self.newcode, False), ("Forget all tablets", self.forget, False)]):
            b = QW.QPushButton(text); b.clicked.connect(fn); b.setMinimumHeight(42)
            if prim: b.setObjectName("primary")
            grid.addWidget(b, i // 2, i % 2)
        self.auto = QW.QCheckBox("Start with Windows"); self.auto.setChecked(autostart_get())
        self.auto.setEnabled(sys.platform == "win32"); self.auto.toggled.connect(autostart_set)
        rc = card(); rl = QW.QVBoxLayout(rc); rl.setContentsMargins(22, 18, 22, 18); rl.setSpacing(6)
        for w in (c1, self.code, c2, self.name): rl.addWidget(w)
        rl.addSpacing(6); rl.addWidget(self.pill, alignment=Qt.AlignmentFlag.AlignLeft); rl.addSpacing(6)
        rl.addLayout(grid); rl.addWidget(self.auto)
        hint = QW.QLabel("Open the TNT Write Tool app on the tablet: this PC appears there. Same Wi-Fi on both."); hint.setStyleSheet("color:#8b949e"); hint.setWordWrap(True)

        right = QW.QVBoxLayout(); right.addLayout(head); right.addWidget(rc); right.addWidget(hint)
        lay = QW.QHBoxLayout(self); lay.setContentsMargins(24, 24, 24, 24); lay.setSpacing(20)
        lay.addWidget(qc); lay.addLayout(right)

        bridge.status.connect(self.set_status)
        bridge.status.connect(lambda d: overlay.toast(f"\u2714  {d} connected" if d else "Tablet disconnected"))
        self.tray = QW.QSystemTrayIcon(app_icon(), self); self.tray.setToolTip(f"{APP} {VERSION}")
        menu = QW.QMenu(); menu.addAction("Open", self.showNormal); menu.addAction("Hide / show board", self.toggle)
        menu.addSeparator(); menu.addAction("Quit", QW.QApplication.quit)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(lambda r: self.showNormal() if r == QW.QSystemTrayIcon.ActivationReason.Trigger else None)
        self.tray.show()
        t = QtCore.QTimer(self); t.timeout.connect(self.refresh); t.start(4000); self.refresh()

    def refresh(self):
        ip = lan_ip()
        url = f"http://{ip}:{self.srv.port}/app?c={self.cfg.code}&n={quote(self.cfg.d['name'])}"
        ok = self.srv.find_apk() is not None
        self.apkl.setText("\u2714 Tablet app ready - the QR installs it" if ok else "\u26A0 Put TNT-Write-Tool.apk next to this program")
        self.apkl.setStyleSheet(f"color:{'#3fb950' if ok else '#f0883e'}")
        self.code.setText(self.cfg.code); self.addr.setText(f"http://{ip}:{self.srv.port}")
        if url != self.url:
            self.url = url
            img = qrcode.make(url, box_size=8, border=2).convert("RGBA").resize((250, 250))
            self._buf = img.tobytes("raw", "RGBA")
            self.qr.setPixmap(QtGui.QPixmap.fromImage(QtGui.QImage(self._buf, 250, 250, QtGui.QImage.Format.Format_RGBA8888)))

    def set_status(self, dev):
        self.pill.setText(f"\u25CF  Connected: {dev}" if dev else "\u25CB  Waiting for a tablet...")
        self.pill.setStyleSheet(f"color:{'#3fb950' if dev else '#8b949e'}")

    def rename(self): self.cfg.d["name"] = self.name.text().strip() or socket.gethostname(); self.cfg.save(); self.refresh()
    def toggle(self): self.overlay.handle({"t": "overlay", "show": not self.overlay.isVisible()})
    def newcode(self): self.cfg.new_code(); self.refresh()
    def forget(self): self.cfg.d["tokens"].clear(); self.cfg.save()

    def closeEvent(self, e):
        e.ignore(); self.hide()
        self.tray.showMessage(APP, "Still running in the tray. Right-click the icon to quit.", QW.QSystemTrayIcon.MessageIcon.Information, 2500)


INSTALL_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / APP


def make_shortcuts(target):
    q = lambda x: str(x).replace("'", "''")
    ps = ("$w=New-Object -ComObject WScript.Shell;"
          "foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){"
          f"$s=$w.CreateShortcut((Join-Path $d '{APP}.lnk'));$s.TargetPath='{q(target)}';"
          f"$s.WorkingDirectory='{q(target.parent)}';$s.IconLocation='{q(target)},0';$s.Description='{APP} {VERSION}';$s.Save()}}")
    subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], creationflags=0x08000000, timeout=40)


def self_install(cfg):
    """Downloaded single .exe: copy to a permanent folder, make Desktop + Start-menu icons, relaunch from there."""
    if sys.platform != "win32" or not getattr(sys, "frozen", False) or "--no-install" in sys.argv:
        return False
    exe, dst = Path(sys.executable), INSTALL_DIR / f"{APP}.exe"
    try:
        if exe.resolve() == dst.resolve():
            return False
        if not (dst.exists() and dst.stat().st_size == exe.stat().st_size):  # new or updated version
            INSTALL_DIR.mkdir(parents=True, exist_ok=True)
            shutil.copy2(exe, dst)
        make_shortcuts(dst)
        if not cfg.d.get("fw"):  # one-time permission so tablets can connect through the Windows firewall
            QW.QMessageBox.information(None, APP, "Windows will ask for permission once, so your tablet can connect.\nPlease click Yes.")
            import ctypes
            ctypes.windll.shell32.ShellExecuteW(None, "runas", "netsh",
                f'advfirewall firewall add rule name="{APP}" dir=in action=allow program="{dst}" enable=yes profile=any', None, 0)
            cfg.d["fw"] = True; cfg.save()
        subprocess.Popen([str(dst)] + sys.argv[1:], close_fds=True, creationflags=0x00000008 | 0x00000200)
        return True
    except Exception as e:
        QW.QMessageBox.warning(None, APP, "To update, close TNT Write Tool first (tray icon > Quit), then open this file again.\n\n" + str(e))
        return False


def main():
    if sys.platform == "win32":
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("tnt.write.tool")
    app = QW.QApplication(sys.argv); app.setQuitOnLastWindowClosed(False); app.setApplicationName(APP)
    cfg = Config()
    if self_install(cfg):
        sys.exit(0)
    lock = QtCore.QLockFile(QtCore.QDir.temp().filePath("tnt_write_tool.lock"))  # only one copy at a time
    if not lock.tryLock(100):
        QW.QMessageBox.information(None, APP, "TNT Write Tool is already running (check the tray icon).")
        sys.exit(0)
    bridge = Bridge()
    srv = Server(cfg, bridge)
    threading.Thread(target=srv.run, daemon=True).start(); srv.ready.wait(5)
    overlay = Overlay(); bridge.cmd.connect(overlay.handle); overlay.show()
    win = Main(cfg, srv, bridge, overlay)
    if "--minimized" not in sys.argv:
        win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
