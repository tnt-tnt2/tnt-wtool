package com.tnt.writetool;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/** Full-screen writing surface. Loads the tablet screen served by the PC app; S Pen events pass straight through. */
public class BoardActivity extends Activity {
    private WebView web;
    private String url;
    private long lastBack;

    /** Lets the page keep its pairing key inside the app, so it survives a changed Wi-Fi address. */
    public class Bridge {
        private final SharedPreferences p = getSharedPreferences("tokens", MODE_PRIVATE);
        @JavascriptInterface public String get(String k) { return p.getString(k, ""); }
        @JavascriptInterface public void set(String k, String v) { p.edit().putString(k, v).apply(); }
        @JavascriptInterface public void del(String k) { p.edit().remove(k).apply(); }
        @JavascriptInterface public String device() { return Build.MANUFACTURER + " " + Build.MODEL; }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        url = getIntent().getStringExtra("url");
        if (url == null) { finish(); return; }

        web = new WebView(this);
        web.setBackgroundColor(0xFF0D1117);
        web.setLongClickable(false);
        web.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { return true; }
        });
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setSupportZoom(false);
        web.addJavascriptInterface(new Bridge(), "TNT");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showError();
            }
        });
        setContentView(web);
        web.loadUrl(url);
    }

    private void showError() {
        String clean = url.contains("?") ? url.substring(0, url.indexOf('?')) : url;
        web.loadDataWithBaseURL(null,
                "<body style='background:#0d1117;color:#e6edf3;font-family:sans-serif;text-align:center;padding-top:15vh'>"
                + "<h1>Can't reach the PC</h1><p style='color:#8b949e'>Make sure TNT Write Tool is open on the PC and both are on the same Wi-Fi.</p>"
                + "<button style='font-size:22px;padding:14px 30px' onclick=\"location.href='" + clean + "'\">Try again</button></body>",
                "text/html", "utf-8", null);
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    public void onBackPressed() {
        if (SystemClock.elapsedRealtime() - lastBack < 2000) { super.onBackPressed(); return; }
        lastBack = SystemClock.elapsedRealtime();
        Toast.makeText(this, "Press back again to leave", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
