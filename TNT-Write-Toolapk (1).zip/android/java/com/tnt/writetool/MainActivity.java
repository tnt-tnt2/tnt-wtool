package com.tnt.writetool;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Home screen: finds the PCs running TNT Write Tool on this Wi-Fi by itself. One tap to connect. */
public class MainActivity extends Activity {
    static final String VERSION = "V5";

    static class Pc { String id, name, ip; int port; long seen; }

    private final Map<String, Pc> found = new HashMap<String, Pc>();
    private final List<Pc> shown = new ArrayList<Pc>();
    private SharedPreferences prefs;
    private ArrayAdapter<String> adapter;
    private TextView status;
    private volatile boolean running = true;
    private boolean autoOpen = true;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WifiManager.MulticastLock lock;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tnt", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0D1117);
        root.setPadding(dp(28), dp(36), dp(28), dp(20));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        head.addView(logo, new LinearLayout.LayoutParams(dp(64), dp(64)));
        TextView title = new TextView(this);
        title.setText("  TNT Write Tool  " + VERSION);
        title.setTextSize(28);
        title.setTextColor(0xFFE6EDF3);
        head.addView(title);
        root.addView(head);

        status = new TextView(this);
        status.setTextSize(16);
        status.setTextColor(0xFF8B949E);
        status.setPadding(0, dp(16), 0, dp(12));
        root.addView(status);

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new ArrayList<String>()) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setTextSize(22);
                t.setTextColor(0xFFE6EDF3);
                t.setPadding(dp(18), dp(20), dp(18), dp(20));
                t.setBackgroundColor(0xFF161B22);
                return t;
            }
        };
        ListView list = new ListView(this);
        list.setAdapter(adapter);
        list.setDivider(new ColorDrawable(0x00000000));
        list.setDividerHeight(dp(10));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < shown.size()) open(shown.get(position));
            }
        });
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));

        Button manual = new Button(this);
        manual.setText("Connect by address");
        manual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { askAddress(); }
        });
        root.addView(manual);
        setContentView(root);

        startListening();
        handler.post(tick);
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    /** Opened from the PC page's "Open" button: tnt://connect?h=IP&p=PORT&c=CODE */
    private void handleIntent(Intent i) {
        Uri d = i == null ? null : i.getData();
        if (d == null || !"tnt".equals(d.getScheme())) return;
        String h = d.getQueryParameter("h"), p = d.getQueryParameter("p"), c = d.getQueryParameter("c");
        if (h == null) return;
        openUrl("http://" + h + ":" + (p == null ? "8765" : p) + "/" + (c != null && c.length() > 0 ? "?c=" + c : ""), null);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long now = SystemClock.elapsedRealtime();
            shown.clear();
            synchronized (found) {
                for (Pc p : found.values()) if (now - p.seen < 8000) shown.add(p);
            }
            adapter.clear();
            for (Pc p : shown) adapter.add("\u25CF  " + p.name + "     " + p.ip);
            adapter.notifyDataSetChanged();
            status.setText(shown.isEmpty()
                    ? "Looking for your PC on this Wi-Fi...\nOpen TNT Write Tool on the PC (same Wi-Fi)."
                    : "Tap your PC to connect");
            if (autoOpen) {
                String last = prefs.getString("last", "");
                for (Pc p : shown) if (p.id.equals(last)) { open(p); break; }
            }
            handler.postDelayed(this, 1000);
        }
    };

    private void startListening() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                    lock = wm.createMulticastLock("tnt");
                    lock.setReferenceCounted(false);
                    lock.acquire();
                } catch (Exception ignored) { }
                DatagramSocket s = null;
                try {
                    s = new DatagramSocket(null);
                    s.setReuseAddress(true);
                    s.bind(new InetSocketAddress(48765));
                    s.setSoTimeout(1000);
                    byte[] buf = new byte[512];
                    while (running) {
                        try {
                            DatagramPacket pk = new DatagramPacket(buf, buf.length);
                            s.receive(pk);
                            String[] a = new String(pk.getData(), 0, pk.getLength(), "UTF-8").split("\\|");
                            if (a.length >= 4 && a[0].equals("TNT1")) {
                                Pc pc = new Pc();
                                pc.name = a[1]; pc.port = Integer.parseInt(a[2]); pc.id = a[3];
                                pc.ip = pk.getAddress().getHostAddress();
                                pc.seen = SystemClock.elapsedRealtime();
                                synchronized (found) { found.put(pc.id, pc); }
                            }
                        } catch (SocketTimeoutException ignored) {
                        } catch (Exception ignored) { }
                    }
                } catch (Exception ignored) {
                } finally {
                    if (s != null) s.close();
                    try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) { }
                }
            }
        }).start();
    }

    private void askAddress() {
        autoOpen = false;
        final EditText addr = new EditText(this);
        addr.setHint("PC address, e.g. 192.168.1.20:8765");
        addr.setInputType(InputType.TYPE_CLASS_TEXT);
        addr.setText(prefs.getString("manual", ""));
        new AlertDialog.Builder(this).setTitle("Connect by address").setView(addr)
                .setPositiveButton("Connect", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String a = addr.getText().toString().trim().replace("http://", "");
                        if (a.endsWith("/")) a = a.substring(0, a.length() - 1);
                        if (a.length() == 0) return;
                        if (!a.contains(":")) a += ":8765";
                        prefs.edit().putString("manual", a).apply();
                        openUrl("http://" + a + "/", null);
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    private void open(Pc p) { openUrl("http://" + p.ip + ":" + p.port + "/", p.id); }

    private void openUrl(String url, String pcId) {
        autoOpen = false;
        if (pcId != null) prefs.edit().putString("last", pcId).apply();
        Intent i = new Intent(this, BoardActivity.class);
        i.putExtra("url", url);
        startActivity(i);
    }

    @Override
    protected void onDestroy() {
        running = false;
        handler.removeCallbacks(tick);
        super.onDestroy();
    }
}
