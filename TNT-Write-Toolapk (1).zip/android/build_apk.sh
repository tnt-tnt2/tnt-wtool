#!/bin/bash
# Builds the Android app without Gradle. usage: build_apk.sh <versionCode> <versionName> <out.apk> <keystore>
set -e
cd "$(dirname "$0")"
VC=$1; VN=$2; OUT=$3; KS=$4
AJ=/usr/lib/android-sdk/platforms/android-23/android.jar
B=/tmp/apkb; rm -rf $B; mkdir -p $B/gen $B/classes
FLAGS=(--min-sdk-version 21 --target-sdk-version 34 --version-code "$VC" --version-name "$VN")
aapt package -f -m -J $B/gen -M AndroidManifest.xml -S res -I $AJ "${FLAGS[@]}"
javac -nowarn --release 8 -classpath $AJ -d $B/classes $(find java $B/gen -name '*.java')
dalvik-exchange --dex --output=$B/classes.dex $B/classes
aapt package -f -M AndroidManifest.xml -S res -I $AJ -F $B/unsigned.apk "${FLAGS[@]}"
(cd $B && aapt add unsigned.apk classes.dex >/dev/null)
zipalign -f 4 $B/unsigned.apk $B/aligned.apk
apksigner sign --ks "$KS" --ks-pass pass:tntwrite --key-pass pass:tntwrite --out "$OUT" $B/aligned.apk
apksigner verify "$OUT" && echo "APK OK: $OUT"
